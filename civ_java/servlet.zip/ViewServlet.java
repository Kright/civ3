import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

import javax.imageio.*;

import java.awt.Graphics2D;
import java.awt.image.*;

/** Simple servlet used to test server.
 *  <P>
 *  Taken from Core Servlets and JavaServer Pages 2nd Edition
 *  from Prentice Hall and Sun Microsystems Press,
 *  http://www.coreservlets.com/.
 *  &copy; 2003 Marty Hall; may be freely used or adapted.
 */

public class ViewServlet extends HttpServlet {
	
  public void doGet(HttpServletRequest request,
                    HttpServletResponse response)
      throws ServletException, IOException {
      	
   
 
  		ServletOutputStream out = response.getOutputStream();
        response.setContentType("image/jpeg");
        
    
    ///////////////////////////
    
  
		
       
            
        // create an image
      //  BufferedImage image= My_PCX.load( "D:\\jeux\\Civilization III\\art\\title.pcx" );      
        BufferedImage image= make_screenshot();
        	
          // encode the output to JPEG
        ImageIO.write(image, "jpeg", out);

          // send the output out
        out.flush();
        out.close();
             
	 
                
  }
  
  private BufferedImage make_screenshot(){
  	
  	// chargement etat
	Civ_State state;
	String filename = "D:\\julien\\dev_java\\civ_java\\demo.biq";
	Civ_Loader sav_file = new Civ_Loader();
	sav_file.bicload(filename);
	state = sav_file.get_state();
	
	// chargement ressource
	Civ_Ressource ressource;
	String civ3_dir = "D:\\jeux\\Civilization III";
	ressource = new Civ_Ressource(civ3_dir);
	ressource.load_from_disk();
	ressource.prechargement_animations(state);
  	
	// generation image
	int viewx, viewy; 
	viewx = ((state.world_w) * 64) / 2;
	viewy = ((state.world_h) * 32) / 2;
	int wscreen = 1024;
	int hscreen = 768;
	BufferedImage image =new BufferedImage(wscreen,
			 hscreen, BufferedImage.TYPE_INT_RGB);
	
	Civ_Draw draw;
	draw = new Civ_Draw();
	draw.configure_input(ressource, state, viewx,
			viewy, wscreen, hscreen,
			0, 1, 0);
	draw.configure_output((Graphics2D) image.createGraphics());
	
	
    long t1 = System.currentTimeMillis();	  
	draw.redraw_background();
	draw.redraw_animation();
	long t2 = System.currentTimeMillis();	
    System .out.println("redraw : " + (t2-t1) +" ms");
	
  	return image;
  }
  
  
  
}
