import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

import java.util.zip.*;

/** Simple servlet used to test server.
 *  <P>
 *  Taken from Core Servlets and JavaServer Pages 2nd Edition
 *  from Prentice Hall and Sun Microsystems Press,
 *  http://www.coreservlets.com/.
 *  &copy; 2003 Marty Hall; may be freely used or adapted.
 */

public class DataServlet extends HttpServlet {
	
  public void doGet(HttpServletRequest request,
                    HttpServletResponse response)
      throws ServletException, IOException {
      	
  		System.out.println("request from " 
  					+ request.getRemoteAddr()
  					+ " (" + request.getRemoteHost() + ")");
 
  		ServletOutputStream out = response.getOutputStream();
        response.setContentType("application/x-civ-net");
        //response.setContentLength(int len)
    
    ///////////////////////////
    
  
		
       
            
         // on charge un BIC
       	Civ_Loader sav_file = new Civ_Loader();
       	sav_file.bicload( "D:\\julien\\dev_java\\civ_java\\demo.biq" );      
        Civ_State p1 = sav_file.get_state();
        System.out.println("p1=" + p1);	     
   
   		// sauvegarde
       	GZIPOutputStream gz_out = new GZIPOutputStream(out);
		ObjectOutputStream s1 = new ObjectOutputStream(gz_out);
		s1.writeObject(p1);
		s1.flush();
		gz_out.close();

        // send the output out
        out.flush();
        out.close();
             
	 
                
  }
}
